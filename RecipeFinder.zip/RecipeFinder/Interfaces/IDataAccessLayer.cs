﻿using RecipeFinder.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeFinder.Interfaces
{
    public interface IDataAccessLayer
    {
        IEnumerable<Ingredient> GetIngredients(string userId);

        void AddIngredient(Ingredient ing);

        void RemoveIngredient(int id, string userId);

        Ingredient GetIngredient(int id, string userId);

        
    }
}
