﻿using Microsoft.EntityFrameworkCore;
using RecipeFinder.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeFinder.Data
{
    public class IngredientContext : DbContext
    {

        public IngredientContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Ingredient> Ingredients { get; set; }
    }
}
