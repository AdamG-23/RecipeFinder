﻿using RecipeFinder.Interfaces;
using RecipeFinder.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeFinder.Data
{
    public class IngredientDAL : IDataAccessLayer
    {
        private IngredientContext _db;

        public IngredientDAL(IngredientContext IContext)
        {
            _db = IContext;
        }

        public void AddIngredient(Ingredient ing)
        {
            _db.Add(ing);
            _db.SaveChanges();
            
        }

        public Ingredient GetIngredient(int id, string userId)
        {
            return _db.Ingredients.Where(i => i.UserId == userId).FirstOrDefault(i => i.Id == id);
        }

        public IEnumerable<Ingredient> GetIngredients(string userId)
        {
            return _db.Ingredients.Where(i => i.UserId == userId).ToList();
        }

        public void RemoveIngredient(int id, string userId)
        {
            Ingredient ingredient = GetIngredient(id, userId);
            if(ingredient != null)
            {
                _db.Ingredients.Remove(ingredient);
                _db.SaveChanges();
            }
        }
    }
}
