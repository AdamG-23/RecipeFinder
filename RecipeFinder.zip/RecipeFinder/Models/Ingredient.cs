﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeFinder.Models
{
    public class Ingredient
    {

        public int? Id { get; set; }

        [Required]
        [MaxLength(450)]
        public string UserId { get; set; }

        public string Title { get; set; }

        public enum Category
        {
            Vegetable, Spices, Dairy, Baking, Sweet, Fruit, Oil, Cheese, 
            Condiments, Meat, Nuts, Dressings, Desserts, Sauces, Soup, Alcohol, 
            Bread, Poultry, Cereal, Legumes, MixedSeasonings, Beverages, Pasta,
            Fish, Seafood, PremadeDough, Supplements
        }

        public Category category { get; set; }

        public Ingredient(int id, string title, Category category)
        {
            this.Id = id;
            this.Title = title;
            this.category = category;
        }

        public Ingredient()
        {
            
        }
    }
}
