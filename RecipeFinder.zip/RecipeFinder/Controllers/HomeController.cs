﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RecipeFinder.Interfaces;
using RecipeFinder.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace RecipeFinder.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        readonly IDataAccessLayer dal;

        public HomeController(IDataAccessLayer dal)
        {
            this.dal = dal;
        }

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return View(dal.GetIngredients(userId));
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult AddIngredient()
        {
            Ingredient ingredient = new Ingredient();
            dal.AddIngredient(ingredient);
            return View("Index");
        }

        public IActionResult AddIngredient(Ingredient ingredient)
        {
            if (ModelState.IsValid)
            {
                if (ingredient.Id.HasValue)
                {
                    Ingredient i = dal.GetIngredient(ingredient.Id.Value, User.FindFirstValue(ClaimTypes.NameIdentifier));
                    i.Title = ingredient.Title;
                    i.category = ingredient.category;
                }

                else
                {
                    dal.AddIngredient(ingredient);
                }
                return View();
            }
            else
            {
                return View();
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
